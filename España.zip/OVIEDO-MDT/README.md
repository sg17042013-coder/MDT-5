# OVIEDO MDT

MDT de roleplay para OVIEDO RP. Interfaz adaptable a móvil, desarrollada con HTML, CSS y JavaScript sin dependencias externas.

## Publicar en GitHub Pages

1. Crea un repositorio en GitHub, por ejemplo `OVIEDO-MDT`.
2. Sube `index.html` y `README.md` a la raíz del repositorio.
3. Entra en **Settings → Pages**.
4. En **Build and deployment**, selecciona **Deploy from a branch**.
5. Selecciona la rama `main` y la carpeta `/ (root)`, y pulsa **Save**.
6. Espera a que GitHub Pages publique la web. La dirección tendrá este formato:
   `https://TU-USUARIO.github.io/OVIEDO-MDT/`

## Funciones incluidas

- Inicio de sesión de roleplay con nombre y placa del agente.
- Estado operativo: disponible, ocupado, en patrulla y fuera de servicio.
- Alta y consulta de ciudadanos.
- Registro y consulta de vehículos.
- Alertas de búsqueda y captura de roleplay.
- Creación de informes policiales.
- Catálogo de multas de ejemplo y calculadora de importes.
- Búsqueda general entre registros.
- Almacenamiento local en el navegador del dispositivo.

## Importante

Esta versión es una demo para roleplay. El acceso por nombre y placa **no es autenticación segura**: cualquiera puede introducir esos datos. Los registros se guardan únicamente en el navegador/dispositivo donde se usan y no se sincronizan entre agentes. No introduzcas datos personales reales. Para uso compartido se necesita un backend con base de datos, autenticación real, permisos y reglas de acceso.

Las cuantías de multas son ejemplos configurables para el servidor y no representan importes oficiales.
